#### Basic Panel Project | #PHP #HTML5 #Bootstrap #JS

#### Software languages used :

* Html5
* Php
* Css
* Javascript

#### Used framework :

* Bootstrap

#### Project screen views :

![Main](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/1.png)
![Register](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/2.png)
![Login](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/3.png)
![Forum](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/4.png)
![Picture](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/5.png)
![Picture-Member](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/5a.png)
![Video](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/6.png)
![Work](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/7.png)
![Maps](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/8.png)

#### Contact :

* GitHub : https://github.com/ismailtasdelen

* YouTube : https://www.youtube.com/c/IsmailTasdelen

* Telegram : https://t.me/ismailtasdelen

* Twitter : https://twitter.com/ismailtsdln

* Linkedin : https://www.linkedin.com/in/ismailtasdelen
